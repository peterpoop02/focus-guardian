#define PIR_PIN 14
#define LDR_PIN 34

void setup() {
  Serial.begin(115200);
  pinMode(PIR_PIN, INPUT);
}

void loop() {
  int motion = digitalRead(PIR_PIN);
  int light = analogRead(LDR_PIN);

  Serial.print("Motion: ");
  Serial.print(motion);

  Serial.print(" | Light: ");
  Serial.println(light);

  delay(2000);
}